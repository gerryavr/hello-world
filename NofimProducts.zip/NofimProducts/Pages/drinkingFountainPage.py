import re
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains

class DrinkingFountainPage():

    def __init__(self, driver):
        self.driver = driver
        self.pageTitle = '//*[@id="post-909"]/div/div/div/div/section[2]/div[4]/div/div/div/div/div[1]/div/h2'
        self.gallery_menu_xpath = '//*[@id="menu-item-19"]/a'
        self.DrinkingFountain_menu_item_id = "menu-item-1179"

    def verifyDrinkingFountainPageTitle(self):
        element=self.driver.find_element_by_xpath(self.pageTitle)
        print(" דף גלריית ",element.text," נפתח בהצלחה ")

    def clickGalleryMenuButton(self):
        # wait for Men menu to appear, then hover it
        action = ActionChains(self.driver)
        firstLevelMenu = self.driver.find_element_by_xpath(self.gallery_menu_xpath)
        action.move_to_element(firstLevelMenu).perform()

    def clickrinkingFountainMenuItem(self):
        self.driver.find_element_by_id(self.DrinkingFountain_menu_item_id).click()