import re
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains

class HomePage():

    def __init__(self, driver):
        self.driver = driver


