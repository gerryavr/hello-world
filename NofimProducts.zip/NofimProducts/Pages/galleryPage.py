import re

class GalleryPage():

    def __init__(self,driver):
        self.driver = driver
        self.pageTitle = '//*[@id="post-919"]/div/div/div/div/section[2]/div[4]/div/div/div/div/div[1]/div/h2'
        self.welcome_id = "welcome"
        self.logout_id = "Logout"


    def verifyBenchesPageTitle(self):
        #text_found = re.search(r'ספסלים', self.driver.page_source)
        #self.assertNotEqual(text_found, None)
        print("aaaa")
        element=self.driver.find_element_by_xpath(self.pageTitle)
        print(element.text)