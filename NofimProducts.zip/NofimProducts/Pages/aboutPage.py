class AboutPage():

    def __init__(self,driver):
        self.driver = driver
        self.pageTitle = '//*[@id="post-10"]/div/div/div/div/section[3]/div[2]/div/div/div/div/section/div/div/div[2]/div/div/div[1]/div/h2'
        self.aboutButton_xpath ="/html/body/div/header/div/div/div/div/div[3]/div/nav/div/ul/li[3]/a"

    def ClickAboutMenuButton(self):
        self.driver.find_element_by_xpath(self.aboutButton_xpath).click()


    def verifyAboutPageOpened(self):
        element=self.driver.find_element_by_xpath(self.pageTitle)
        print(" דף אודות ",element.text," נפתח בהצלחה ")