class ContactPage():

    def __init__(self,driver):
        self.driver = driver
        # wpcf7-f1855-p12-o1 > form > p:nth-child(2) > label > span > input
        self.name_xpath = "//*[@id='wpcf7-f1855-p12-o1']/form/p[1]/label/span/input"
        #self.name_selector ="wpcf7-f1855-p12-o1 > form > p:nth-child(2) > label > span > input"
        #self.email_xpath = "//*[@id='wpcf7-f1855-p12-o1']/form/p[2]/label/span/input"
        self.email_selector = ".wpcf7-email"
        self.subject_xpath = "//*[@id='wpcf7-f1855-p12-o1']/form/p[3]/label/span/input"
        #self.subject_selector = "#wpcf7-f1855-p12-o1 > form > p:nth-child(4) > label > span > input"
        #self.message_xpath = "//*[@id='wpcf7-f1855-p12-o1']/form/p[4]/label/span/textarea"
        self.message_selector = "textarea.wpcf7-form-control"
        self.send_button_xpath = "//*[@id='wpcf7-f1855-p12-o1']/form/p[5]/input"
        self.send_button_css_selctor= ".wpcf7-submit"
        self.verify_sending_button_clicked_xpath =".wpcf7-response-output"
        #self.username_textbox_id = Locators.username_textbox_id # if using locators

        #.wpcf7 - submit
    def enterName(self,name):
        #self.driver.find_element_by_css_selector(self.name_selector).clear()
        self.driver.find_element_by_xpath(self.name_xpath).send_keys(name)


    def enterEmail(self,email):
        #self.driver.find_element_by_css_selector(self.email_selector).clear()
        self.driver.find_element_by_css_selector(self.email_selector).send_keys(email)

    def enterSubject(self, subject):
        #self.driver.find_element_by_css_selector(self.subject_selector).clear()
        self.driver.find_element_by_xpath(self.subject_xpath).send_keys(subject)

    def enterMessage(self, message):
        #self.driver.find_element_by_css_selector(self.message_selector).clear()
        self.driver.find_element_by_css_selector(self.message_selector).send_keys(message)

    def SendMessage(self):
        self.driver.find_element_by_css_selector(self.send_button_css_selctor).click()
        #self.driver.find_element_by_id(self.send_button_xpath).click()

    def verify_sending(self):
        msg = self.driver.find_element_by_xpath(self.verify_sending_button_clicked_xpath).text
        print(msg)
        return msg
