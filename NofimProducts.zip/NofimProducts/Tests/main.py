from selenium import webdriver
import  time
import unittest
import sys
import os
import HtmlTestRunner
from Pages.homePage import HomePage
from Pages.benchesPage import BenchesPage
from Pages.accessibilityTablesPage import AccessibilityTablesPage
from Pages.tinPage import TinPage
from Pages.picnicTablesPage import PicnicTablesPage
from Pages.picnicProductsPage import PicnicProductsPage
from Pages.drinkingFountainPage import DrinkingFountainPage
from Pages.plantersPage import PlantersPage
from Pages.woodWorkPage import WoodWorkPage
from Pages.woodenTablesPage import WoodenTablesPage
from Pages.concreteTablesPage import ConcreteTablesPage
from Pages.contactPage import ContactPage
from Pages.aboutPage import AboutPage




sys.path.append(os.path.join(os.path.dirname(__file__),"...","..."))

#cmd run # C:\Users\GA333\PycharmProjects\PO1>python -m unittest Tests.login
#Generate html reports # python -m Tests.login

class LoginTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Firefox(executable_path="C:\pycahrm_drivers\geckodriver-v0.24.0-win64\geckodriver.exe")
        cls.driver.implicitly_wait(10)
        cls.driver.maximize_window()

    #Benches Page
    def test_01(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        benchesPage = BenchesPage(driver)
        benchesPage.clickGalleryMenuButton()
        time.sleep(2)
        benchesPage.clickBencheMenuItem()
        time.sleep(2)
        benchesPage.verifyBenchesPageTitle()
        time.sleep(2)
        #driver.execute_script("window.history.go(-1)")
        driver.back()

    #TinPage
    def test_02(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        tinPage = TinPage(driver)
        tinPage.clickGalleryMenuButton()
        time.sleep(2)
        tinPage.clickTinMenuItem()
        time.sleep(2)
        tinPage.verifyTinPageTitle()
        time.sleep(2)

    #AccessibilityTablesPage
    def test_03(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        accessibilityTablesPage = AccessibilityTablesPage(driver)
        accessibilityTablesPage.clickGalleryMenuButton()
        time.sleep(2)
        accessibilityTablesPage.clickAccessibilityTableMenuItem()
        time.sleep(2)
        accessibilityTablesPage.verifyAccessibilityTablePageTitle()
        time.sleep(2)

    #PicnicTablesPage
    def test_04(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        picnicTablesPage = PicnicTablesPage(driver)
        picnicTablesPage.clickGalleryMenuButton()
        time.sleep(2)
        picnicTablesPage.clickPicnicTableMenuItem()
        time.sleep(2)
        picnicTablesPage.verifyPicnicTablesPageTitle()
        time.sleep(2)

    #PicnicProductsPage
    def test_05(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        picnicProductsPage = PicnicProductsPage(driver)
        picnicProductsPage.clickGalleryMenuButton()
        time.sleep(2)
        picnicProductsPage.clickPicnicProductsMenuItem()
        time.sleep(2)
        picnicProductsPage.verifyPicnicProductsPageTitle()
        time.sleep(2)

    #DrinkingFountainPage
    def test_06(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        drinkingFountainPage = DrinkingFountainPage(driver)
        drinkingFountainPage.clickGalleryMenuButton()
        time.sleep(2)
        drinkingFountainPage.clickrinkingFountainMenuItem()
        time.sleep(2)
        drinkingFountainPage.verifyDrinkingFountainPageTitle()
        time.sleep(2)

    #PlantersPage
    def test_07(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        plantersPage = PlantersPage(driver)
        plantersPage.clickGalleryMenuButton()
        time.sleep(2)
        plantersPage.clickPlantersPageMenuItem()
        time.sleep(2)
        plantersPage.verifyPlantersPageTitle()
        time.sleep(2)

    #WoodWorkPage
    def test_08(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        woodWorkPage = WoodWorkPage(driver)
        woodWorkPage.clickGalleryMenuButton()
        time.sleep(2)
        woodWorkPage.clickWoodWorkMenuItem()
        time.sleep(2)
        woodWorkPage.verifyWoodWorkPageTitle()
        time.sleep(2)

    #WoodenTablesPage
    def test_09(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        woodenTablesPage = WoodenTablesPage(driver)
        woodenTablesPage.clickGalleryMenuButton()
        time.sleep(2)
        woodenTablesPage.clickWoodenTablesMenuItem()
        time.sleep(2)
        woodenTablesPage.verifyWoodenTablesPageTitle()
        time.sleep(2)

    #ConcreteTablesPage
    def test_10(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/")
        concreteTablesPage = ConcreteTablesPage(driver)
        concreteTablesPage.clickGalleryMenuButton()
        time.sleep(2)
        concreteTablesPage.clickConcreteTablesMenuItem()
        time.sleep(2)
        concreteTablesPage.verifyConcreteTablesPageTitle()
        time.sleep(2)

    #AboutPage
    def test_11(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il")
        aboutPage = AboutPage(driver)
        aboutPage.ClickAboutMenuButton()
        aboutPage.verifyAboutPageOpened()
        time.sleep(2)

    #ContactPage
    def test_12(self):
        driver = self.driver
        driver.get("https://nofim-products.co.il/contact-us/")
        contactPage = ContactPage(driver)
        contactPage.enterName("test1")
        contactPage.enterEmail("test2@yamline.com")
        contactPage.enterSubject("subject1 ")
        contactPage.enterMessage("msg1 ")
        #contactPage.SendMessage()
        time.sleep(2)
        #contactPage.verify_sending()
        time.sleep(2)



    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")

if (__name__=="__main__"):
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='c:/Users/GA333/PycharmProjects/NofimProducts/Reports'))


